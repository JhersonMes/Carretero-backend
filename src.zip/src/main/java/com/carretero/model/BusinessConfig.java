package com.carretero.model;

import com.carretero.model.enums.SunatEnvironment;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "business_config")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class BusinessConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @EqualsAndHashCode.Include
    private Integer idConfig;

    @Column(nullable = false, length = 150)
    private String businessName = "EL CARRETERO";

    @Column(length = 150)
    private String commercialName = "EL CARRETERO BURGERS & WINGS";

    @Column(length = 20)
    private String ruc = "20000000001";

    @Column(length = 255)
    private String address = "Av. Principal 123";

    @Column(length = 30)
    private String phone = "999888777";

    @Column(length = 100)
    private String email;

    /**
     * PIN que autoriza anular una venta o reemitir su comprobante.
     *
     * Se guarda cifrado, igual que las contrasenas: quien tenga acceso a la base
     * no debe poder leer el codigo con el que se anulan ventas. Por eso tampoco
     * viaja nunca en el DTO de configuracion.
     */
    @Column(name = "admin_pin", length = 200)
    private String adminPin;

    // Series de facturación
    @Column(length = 10)
    private String boletaSeries = "B001";

    @Column(length = 10)
    private String facturaSeries = "F001";

    @Column(length = 10)
    private String notaVentaSeries = "NV01";

    // Configuración API DNI / RUC y SUNAT

    /**
     * Ambiente contra el que se emiten los comprobantes.
     *
     * Se elige a mano y no se deduce de si hay token cargado: pasar a produccion
     * tiene que ser una decision visible. Queda nullable a proposito para que
     * agregar la columna no rompa las bases que ya existen; quien la lee trata el
     * null como SIMULADO.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "sunat_environment", length = 20)
    private SunatEnvironment sunatEnvironment = SunatEnvironment.SIMULADO;

    @Column(length = 255)
    private String sunatApiUrl;

    @Column(length = 255)
    private String sunatApiToken;

    @Column(length = 255)
    private String dniRucApiUrl = "https://apiperu.dev/api";

    @Column(length = 255)
    private String dniRucApiToken;

    // Impresoras Térmicas de Red (Ethernet / WiFi)
    @Column(length = 50)
    private String kitchenPrinterIp = "192.168.1.200";

    @Column
    private Integer kitchenPrinterPort = 9100;

    @Column
    private boolean kitchenPrinterEnabled = false;

    @Column(length = 50)
    private String barPrinterIp = "192.168.1.201";

    @Column
    private Integer barPrinterPort = 9100;

    @Column
    private boolean barPrinterEnabled = false;

    @Column(length = 50)
    private String cashierPrinterIp = "192.168.1.202";

    @Column
    private Integer cashierPrinterPort = 9100;

    @Column
    private boolean cashierPrinterEnabled = false;

    @Column(nullable = false)
    private boolean active = true;
}
